package com.vehicle.bookingapp.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vehicle.bookingapp.Repo.BookCabRepository;
import com.vehicle.bookingapp.BookCab;

@Service
public class BookServiceImpls implements BookCabService {

	@Autowired
	BookCabRepository bookr;

	@Override
	public String BookNewCab(BookCab bc) {
		BookCab b = bookr.save(bc);
		if (b != null)
			return "success";
		return "Err";
	}

	@Override
	public List<BookCab> ListAllBookings() {
		List<BookCab> booklist = bookr.findAll();
		return booklist;
	}

	@Override
	public BookCab searchMyBookings(int id) {
		Optional<BookCab> b1 = bookr.findById(id);
		if (b1.isPresent())
			return b1.get();
		return null;
	}

	@Override
	public String DeleteBooking(int id) {
		bookr.deleteById(id);
		return "Success";
	}

	@Override
	public String ModifyBooking(BookCab bc) {
		if (bc != null && bc.getBookID() != 0) {
			Optional<BookCab> existingBooking = bookr.findById(bc.getBookID());
			if (existingBooking.isPresent()) {
				BookCab existingCabBooking = existingBooking.get();
				
				existingCabBooking.setBookingDate(bc.getBookingDate());
				existingCabBooking.setFrom(bc.getFrom());
				existingCabBooking.setTo(bc.getTo());
				existingCabBooking.setVechNo(bc.getVechNo());
				existingCabBooking.setCustomerName(bc.getCustomerName());
				existingCabBooking.setPhone(bc.getPhone());
				
				// Save the updated cab fare to the database
				bookr.save(existingCabBooking);
				return "Success";
			}
		}
		return "Failure";
	}

}
