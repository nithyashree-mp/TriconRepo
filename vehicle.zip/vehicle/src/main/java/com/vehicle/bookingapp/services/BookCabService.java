package com.vehicle.bookingapp.services;

import java.util.List;

import com.vehicle.bookingapp.BookCab;

public interface BookCabService {
	
	public String BookNewCab(BookCab bc);

	public List<BookCab> ListAllBookings();
    
	public BookCab searchMyBookings(int id);
	
	public String DeleteBooking(int id);

	public String ModifyBooking(BookCab bc);


}
