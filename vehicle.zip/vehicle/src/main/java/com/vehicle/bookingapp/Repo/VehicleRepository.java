package com.vehicle.bookingapp.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.vehicle.bookingapp.Vehicle;

@Repository
public interface VehicleRepository extends JpaRepository<Vehicle,Integer>{

}
