package com.vehicle.bookingapp;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity

public class Vehicle {
	@Id
	@GeneratedValue

	int Vid;
	String VechName;
	int VechNo;
	String OwnerName;
	int Seats;
	long Phone;

	public int getVid() {
		return Vid;
	}

	public void setVid(int vid) {
		Vid = vid;
	}

	public String getVechName() {
		return VechName;
	}

	public void setVechName(String vechName) {
		VechName = vechName;
	}

	public int getVechNo() {
		return VechNo;
	}

	public void setVechNo(int vechNo) {
		VechNo = vechNo;
	}

	public String getOwnerName() {
		return OwnerName;
	}

	public void setOwnerName(String ownerName) {
		OwnerName = ownerName;
	}

	public int getSeats() {
		return Seats;
	}

	public void setSeats(int seats) {
		Seats = seats;
	}

	public long getPhone() {
		return Phone;
	}

	public void setPhone(long phone) {
		Phone = phone;
	}

}
