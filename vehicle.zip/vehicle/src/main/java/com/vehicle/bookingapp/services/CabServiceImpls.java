package com.vehicle.bookingapp.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vehicle.bookingapp.Repo.CabFareRepository;
import com.vehicle.bookingapp.CabFare;

@Service
public class CabServiceImpls implements CabFareService{

	@Autowired
	CabFareRepository cabr;
	
	@Override
	public String AddCab(CabFare cab) {
		CabFare c = cabr.save(cab);
		if(c != null)
			return "success";
		return "Err";
	}

	@Override
	public List<CabFare> CabAll() {
		List<CabFare> cablist = cabr.findAll();
		return cablist;
	}

	@Override
	public CabFare SearchCab(int id) {
		Optional<CabFare> cab = cabr.findById(id);
		if (cab.isPresent())
			return cab.get();
		return null;
	}

	@Override
	public String DeleteCabFare(int id) {
		cabr.deleteById(id);
		return "Success";
	}

	@Override
	public String ModifyCab(CabFare cabFare) {
		if (cabFare != null && cabFare.getId() != 0) {
			Optional<CabFare> existingCabFareOptional = cabr.findById(cabFare.getId());
			if (existingCabFareOptional.isPresent()) {
				CabFare existingCabFare = existingCabFareOptional.get();
				
				existingCabFare.setPickuploc(cabFare.getPickuploc());
				existingCabFare.setDroploc(cabFare.getDroploc());
				existingCabFare.setFare(cabFare.getFare());
				// Save the updated cab fare to the database
				cabr.save(existingCabFare);
				return "Success";
			}
		}
		return "Failure";
	}
	

}
