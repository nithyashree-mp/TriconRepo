package com.vehicle.bookingapp.services;

import java.util.List;

import com.vehicle.bookingapp.CabFare;

public interface CabFareService {

	public String AddCab(CabFare cab);

	public List<CabFare> CabAll();

	public CabFare SearchCab(int id);

	public String DeleteCabFare(int id);

	public String ModifyCab(CabFare cabFare);


}
