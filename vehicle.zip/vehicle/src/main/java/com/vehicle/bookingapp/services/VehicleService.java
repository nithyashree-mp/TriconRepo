package com.vehicle.bookingapp.services;

import java.util.List;

import com.vehicle.bookingapp.Vehicle;

public interface VehicleService {
	public String AddVehicle(Vehicle vh);

	public List<Vehicle> AllVehicle();

	public Vehicle Searchvehicle(int id);

	public String Deletevehicle(int id);

	public String Modifyvehicle(Vehicle vh);


}
