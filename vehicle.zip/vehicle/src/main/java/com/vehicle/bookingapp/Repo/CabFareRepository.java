package com.vehicle.bookingapp.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.vehicle.bookingapp.CabFare;

@Repository
public interface CabFareRepository extends JpaRepository<CabFare,Integer> {

}
