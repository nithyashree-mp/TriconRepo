package com.vehicle.bookingapp;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity

public class CabFare {
	@Id
	@GeneratedValue
	int id;
	String pickuploc;
	String droploc;
	float fare;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPickuploc() {
		return pickuploc;
	}

	public void setPickuploc(String pickuploc) {
		this.pickuploc = pickuploc;
	}

	public String getDroploc() {
		return droploc;
	}

	public void setDroploc(String droploc) {
		this.droploc = droploc;
	}

	public float getFare() {
		return fare;
	}

	public void setFare(float fare) {
		this.fare = fare;
	}

}
