package com.vehicle.bookingapp.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.vehicle.bookingapp.Vehicle;
import com.vehicle.bookingapp.services.VehicleService;

@Controller

public class VehicleController {
	@Autowired
	VehicleService vs;

	@GetMapping("/newvehicle")
	public String AddVehicle(Model m) {
		m.addAttribute("bookcab", new Vehicle());
		return "AddVehicle";
	}

	@PostMapping("newbookinginfo")
	public String NewBook(@ModelAttribute Vehicle vehicle, Model m) {
		String res = vs.AddVehicle(vehicle);
		if (res.equals("Success")) {
			m.addAttribute("info", "");
			m.addAttribute("vehicle", new Vehicle());
		}
		return "redirect:/caball";
	}

	@GetMapping("allvehicles")
	public String ViewAll(Model m) {
		List<Vehicle> vechlist = vs.AllVehicle();
		m.addAttribute("vechlist", vechlist);
		return "ViewVehicles";
	}

	@GetMapping("modifyvehicles/{id}")
	public String modifyVehicles(@PathVariable int id, Model m) {
		Vehicle vehicle = vs.Searchvehicle(id);
		m.addAttribute("vehicle", vehicle);
		return "ModifyVehicles";
	}

	@PostMapping("modifyvehicles/{id}")
	public String Modifyvehicle(@ModelAttribute Vehicle vehicle, Model m) {
		String result = vs.Modifyvehicle(vehicle);
		if (result.equals("Success")) {
			m.addAttribute("info", "Cab fare modified successfully.");
		} else {
			m.addAttribute("info", "Failed to modify cab fare.");
		}
		return "redirect:/caball";
	}

	@GetMapping("delcab/{id}")
	public String Deletevehicle(@PathVariable int id) {
		vs.Deletevehicle(id);
		return "redirect:/caball";
	}
}

