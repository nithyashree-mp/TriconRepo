package com.vehicle.bookingapp.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.vehicle.bookingapp.BookCab;
import com.vehicle.bookingapp.services.BookCabService;

@Controller
public class BookCabController {

	@Autowired
	BookCabService bs;

	@GetMapping("/newbooking")
	public String BookNewCab(Model m) {
		m.addAttribute("bookcab", new BookCab());
		return "AddBookCab";
	}

	@PostMapping("newbookinginfo")
	public String NewBook(@ModelAttribute BookCab bookcab, Model m) {
		String res = bs.BookNewCab(bookcab);
		if (res.equals("Success")) {
			m.addAttribute("info", "");
			m.addAttribute("bookcab", new BookCab());
		}
		return "redirect:/caball";
	}

	@GetMapping("allbooking")
	public String ViewAll(Model m) {
		List<BookCab> booklist = bs.ListAllBookings();
		m.addAttribute("booklist", booklist);
		return "ViewBookings";
	}

	@GetMapping("modifybooking/{id}")
	public String modifyBooking(@PathVariable int id, Model m) {
		BookCab bookcab = bs.searchMyBookings(id);
		m.addAttribute("bookCab", bookcab);
		return "ModifyBookings";
	}

	@PostMapping("modifycab/{id}")
	public String modifyCabInfo(@ModelAttribute BookCab bookcab, Model m) {
		String result = bs.ModifyBooking(bookcab);
		if (result.equals("Success")) {
			m.addAttribute("info", "Cab fare modified successfully.");
		} else {
			m.addAttribute("info", "Failed to modify cab fare.");
		}
		return "redirect:/caball";
	}

	@GetMapping("delcab/{id}")
	public String DeleteCab(@PathVariable int id) {
		bs.DeleteBooking(id);
		return "redirect:/caball";
	}
}
