package com.vehicle.bookingapp.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vehicle.bookingapp.Repo.VehicleRepository;
import com.vehicle.bookingapp.Vehicle;

@Service
public class VehicleServiceImpls implements VehicleService {

	@Autowired
	VehicleRepository vhr;

	@Override
	public String AddVehicle(Vehicle vh) {
		Vehicle v = vhr.save(vh);
		if(v!=null)
			return "success";
		return "Err";
	}

	@Override
	public List<Vehicle> AllVehicle() {
		List<Vehicle> vehicleList = vhr.findAll();
		return vehicleList;
	}

	@Override
	public Vehicle Searchvehicle(int id) {
		Optional<Vehicle> v = vhr.findById(id);
		if(v.isPresent())
			return v.get();
		return null;
	}

	@Override
	public String Deletevehicle(int id) {
		vhr.deleteById(id);
		return "success";
	}

	@Override
	public String Modifyvehicle(Vehicle vh) {
		if(vh != null && vh.getVid()!=0)
		{
			Optional<Vehicle> existingVehicle = vhr.findById(vh.getVid());
			
			if(existingVehicle.isPresent())
			{
				Vehicle vehicle = existingVehicle.get();
				
				vehicle.setVechName(vh.getVechName());
				vehicle.setVechNo(vh.getVechNo());
				vehicle.setSeats(vh.getSeats());
				vehicle.setOwnerName(vh.getOwnerName());
				vehicle.setPhone(vh.getPhone());
				
				vhr.save(vehicle);
				return "success";
			}
			
		}
		return "failure";
	}

}